            <!-- Banner Section Start -->
            <div class="rs-banner main-home">
                <div class="container">
                    <div class="content-wrap">
                        <div class="icon-wrap mb-50">
                            <img src="{{ asset('frontend/assets/images/banner/style1/brands.png') }}" alt="Images">
                        </div>
                        <h2 class="underline-text">WELCOME</h2>
                        <div class="prelements-heading water__slide_yes default text-center">
                            <div class="title-inner">                           
                                <h2 class="title"><span class="watermark">Forex Arena</span>For<span>ex</span>arena</h2>             
                            </div>
                        </div>
                        <h2 class="conference-title">Conference <span class="year">2022</span></h2>
                        <div class="btn-part">
                            <a class="readon btn-text" href="contact.html">
                                <span>Purchase Ticket</span>
                                <img src="{{ asset('frontend/assets/images/event.png') }}" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Banner Section End -->