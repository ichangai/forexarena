@extends('frontend.layouts.master')

@section('content')

@include('frontend.components.banner')

@include('frontend.components.events.event')


@endsection