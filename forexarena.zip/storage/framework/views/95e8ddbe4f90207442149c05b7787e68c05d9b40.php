
<script src="<?php echo e(asset('frontend/assets/js/jquery.min.js')); ?>"></script>
        <!-- modernizr js -->
        <script src="<?php echo e(asset('frontend/assets/js/bootstrap.min.js')); ?>"></script>

        <script src="<?php echo e(asset('frontend/assets/js/modernizr-2.8.3.min.js')); ?>"></script>
        <!-- jquery latest version -->
        <!-- Bootstrap v4.4.1 js -->
        <!-- op nav js -->
        <script src="<?php echo e(asset('frontend/assets/js/jquery.nav.js')); ?>"></script>
        <!-- isotope.pkgd.min js -->
        <script src="<?php echo e(asset('frontend/assets/js/isotope.pkgd.min.js')); ?>"></script>
        <!-- owl.carousel js -->
        <script src="<?php echo e(asset('frontend/assets/js/owl.carousel.min.js')); ?>"></script>
        <!-- wow js -->
        <script src="<?php echo e(asset('frontend/assets/js/wow.min.js')); ?>"></script>
        <!-- Time Circle js -->
        <script src="<?php echo e(asset('frontend/assets/js/time-circle.js')); ?>"></script>
        <!-- Skill bar js -->
        <script src="<?php echo e(asset('frontend/assets/js/skill.bars.jquery.js')); ?>"></script>
        <!-- imagesloaded js -->
        <script src="<?php echo e(asset('frontend/assets/js/imagesloaded.pkgd.min.js')); ?>"></script>
         <!-- waypoints.min js -->
        <script src="<?php echo e(asset('frontend/assets/js/waypoints.min.js')); ?>"></script>
        <!-- counterup.min js -->
        <script src="<?php echo e(asset('frontend/assets/js/jquery.counterup.min.js')); ?>"></script> 
        <!-- magnific popup js -->
        <script src="<?php echo e(asset('frontend/assets/js/jquery.magnific-popup.min.js')); ?>"></script>
        <!-- contact form js -->
        <script src="<?php echo e(asset('frontend/assets/js/contact.form.js')); ?>"></script>
        <!-- main js -->
        <script src="<?php echo e(asset('frontend/assets/js/main.js')); ?>"></script>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

            </body>

</html><?php /**PATH C:\xampp\htdocs\forexarena\resources\views/frontend/layouts/scripts.blade.php ENDPATH**/ ?>